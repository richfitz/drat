library(testthat)
library(buildr)

test_check("buildr")
