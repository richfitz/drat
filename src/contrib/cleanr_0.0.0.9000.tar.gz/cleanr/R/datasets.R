#' Data set included with the package
#' @name epi.sim
#' @keywords data
NULL
