library(testthat)
library(cleanr)

test_check("cleanr")
