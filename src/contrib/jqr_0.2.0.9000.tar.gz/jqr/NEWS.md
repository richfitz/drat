jqr 0.2.0
==============

NEW FEATURES

* Released to CRAN.
