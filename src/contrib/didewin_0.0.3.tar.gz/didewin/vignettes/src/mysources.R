make_tree <- function(nspp) {
  message("I am building a tree!")
  ape::rtree(nspp)
}
