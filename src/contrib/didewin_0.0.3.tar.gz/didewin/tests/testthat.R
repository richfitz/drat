library(testthat)
library(didewin)

test_check("didewin")
