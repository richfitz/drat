## ----setup, echo=FALSE, results="hide"-----------------------------------
lang_output <- function(x, lang) {
  cat(c(sprintf("```%s", lang), x, "```"), sep="\n")
}
c_output <- function(x) lang_output(x, "cc")
r_output <- function(x) lang_output(x, "r")
plain_output <- function(x) lang_output(x, "plain")
knitr::opts_chunk$set(
  fig.width=7,
  fig.height=5)

## ------------------------------------------------------------------------
path_logistic <- system.file("examples/logistic.R", package="odin")

## ----echo=FALSE, results="asis"------------------------------------------
r_output(readLines(path_logistic))

## ------------------------------------------------------------------------
generator <- odin::odin(path_logistic, verbose=FALSE)

## ------------------------------------------------------------------------
mod <- generator()
mod

## ------------------------------------------------------------------------
mod$init

## ------------------------------------------------------------------------
mod$deriv(0, mod$init)

## ------------------------------------------------------------------------
mod$deriv(0, 50)

## ------------------------------------------------------------------------
mod$contents()

## ------------------------------------------------------------------------
tt <- seq(0, 30, length.out=101)
y <- mod$run(tt)
plot(y, xlab="Time", ylab="N", las=1, main="")

## ------------------------------------------------------------------------
y2 <- mod$run(tt, 50)
plot(y, xlab="Time", ylab="N", las=1, main="")
lines(y2, col="red")

## ------------------------------------------------------------------------
generator <- odin::odin({
  deriv(N) <- r * N * (1 - N / K)
  initial(N) <- N0

  N0 <- user(1)
  K <- user(100)
  r <- user()
}, verbose=FALSE)

## ----error=TRUE----------------------------------------------------------
generator()

## ------------------------------------------------------------------------
mod <- generator(r=1)

## ------------------------------------------------------------------------
mod$contents()$r

## ------------------------------------------------------------------------
y3 <- mod$run(tt)
plot(y, xlab="Time", ylab="N", las=1, main="")
lines(y3, col="red")

## ------------------------------------------------------------------------
mod$set_user(r=0.25, K=75, N0=10)
y4 <- mod$run(tt)
plot(y, xlab="Time", ylab="N", las=1, main="")
lines(y3, col="red")
lines(y4, col="blue")

## ------------------------------------------------------------------------
mod$set_user(whatever=1)

## ------------------------------------------------------------------------
path_lorenz <- system.file("examples/lorenz.R", package="odin")

## ----echo=FALSE, results="asis"------------------------------------------
r_output(readLines(path_lorenz))

## ------------------------------------------------------------------------
generator <- odin::odin(path_lorenz, verbose=FALSE)
mod <- generator()

## ------------------------------------------------------------------------
tt <- seq(0, 100, length.out=20000)
system.time(y <- mod$run(tt))
pairs(y[, -1L], panel=lines, lwd=.2, col="#00000055")

## ------------------------------------------------------------------------
gen <- odin::odin({
  ylag <- delay(y, tau)
  initial(y) <- 0.5
  deriv(y) <- 0.2 * ylag * 1 / (1 + ylag^10) - 0.1 * y
  tau <- user(10)
  output(ylag) <- ylag
})
dde <- gen()

## ------------------------------------------------------------------------
t <- seq(0, 300, length.out=301)
y1 <- dde$run(t)
plot(y1, ylab = "y", mfrow=c(1, 2), which=1)
plot(y1[, -1L], xlab="y", ylab = "ylag", mfrow=NULL, type="l")

## ------------------------------------------------------------------------
dde$set_user(tau=20)
y2 <- dde$run(t)
plot(y2, ylab = "y", mfrow=c(1, 2), which=1)
plot(y2[, -1L], xlab="y", ylab = "ylag", mfrow=NULL, type="l")

## ------------------------------------------------------------------------
gen <- odin::odin({
  deriv(y[]) <- r[i] * y[i] * (1 - sum(ay[i, ]))
  initial(y[]) <- y0[i]

  y0[] <- user()
  r[] <- user()
  a[,] <- user()
  ay[,] <- a[i, j] * y[j]

  dim(r) <- user()
  n_spp <- length(r)

  dim(y) <- n_spp
  dim(y0) <- n_spp
  dim(a) <- c(n_spp, n_spp)
  dim(ay) <- c(n_spp, n_spp)

  config(base) <- "lv4"
})

## ------------------------------------------------------------------------
pars <- list(r=c(1.00, 0.72, 1.53, 1.27),
             a=rbind(c(1.00, 1.09, 1.52, 0.00),
                     c(0.00, 1.00, 0.44, 1.36),
                     c(2.33, 0.00, 1.00, 0.47),
                     c(1.21, 0.51, 0.35, 1.00)),
             y0=c(0.3013, 0.4586, 0.1307, 0.3557))

## ------------------------------------------------------------------------
mod <- gen(user=pars)

t <- seq(0, 2000, length.out=10001)
y <- mod$run(t)
pairs(y[, -1], panel=lines, col="#00000055", lwd=0.2)

