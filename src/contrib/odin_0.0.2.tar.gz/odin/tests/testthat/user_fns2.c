double squarepulse(double t,
                   double t0,
                   double t1) {
  return t >= t0 && t < t1;
}
