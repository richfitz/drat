library(testthat)
library(odin)

test_check("odin")
