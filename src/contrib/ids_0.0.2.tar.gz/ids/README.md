# ids

> ids

[![Linux Build Status](https://travis-ci.org/richfitz/ids.svg?branch=master)](https://travis-ci.org/richfitz/ids)

ids

Based on
https://github.com/a-type/adjective-adjective-animal

## Installation

```r
devtools::install_github("richfitz/ids")
```

## Usage

```r
library(ids)
f <- ids::adjective_animal(2)
f()
f(10)
```

## License

MIT
