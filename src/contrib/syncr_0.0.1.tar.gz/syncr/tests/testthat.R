library(testthat)
library(syncr)

test_check("syncr")
