#include <Rconfig.h>
#ifdef WORDS_BIGENDIAN
  #define IEEE_MC68k
#else
  #define IEEE_8087
#endif
