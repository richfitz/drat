library(testthat)
library(redux)

test_check("redux")
