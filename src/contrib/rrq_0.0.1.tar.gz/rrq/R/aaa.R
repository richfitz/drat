##' @importFrom stats setNames
##' @import utils
##' @importFrom R6 R6Class
NULL
