
#' Simple Redis Queue
#'
#' Simple Redis queue in R.
#'
#' @docType package
#' @name rrq
NULL
