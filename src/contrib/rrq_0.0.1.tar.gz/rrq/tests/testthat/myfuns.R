slowdouble <- function(x) {
  Sys.sleep(x)
  x * 2
}
