library(testthat)
library(seagull)

test_check("seagull")
