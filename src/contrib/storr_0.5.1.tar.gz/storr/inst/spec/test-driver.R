## TODO: check that *updating* a key works in the spec tests (i.e., hit set_hash(key, namespace, hash)
## This requires
##   .driver_name: character(1)
##   .driver_create: function()
testthat::context(sprintf("drivers [%s]", .driver_name))

testthat::test_that("basic (empty)", {
  dr <- .driver_create()
  on.exit(dr$destroy())

  testthat::expect_equal(dr$type(), .driver_name)

  ns <- "objects"
  testthat::expect_equal(dr$list_namespaces(), character(0))
  testthat::expect_equal(dr$list_hashes(), character(0))
  testthat::expect_equal(dr$list_keys(ns), character(0))

  h <- "aaa"
  k <- "bbb"
  ns <- "ns"

  testthat::expect_false(dr$exists_hash(h))
  testthat::expect_false(dr$exists_key(k, ns))

  testthat::expect_false(dr$del_hash(h))
  testthat::expect_false(dr$del_key(h, ns))
})

testthat::test_that("set", {
  dr <- .driver_create()
  on.exit(dr$destroy())

  ## First, let's set some data to a hash
  d <- runif(100)
  h <- hash_object(d)
  k <- "bbb"
  ns <- "ns"

  dr$set_object(h, d)
  testthat::expect_equal(dr$get_object(h), d, tolerance=1e-15)

  ## Then, set a key to address that hash:
  dr$set_hash(k, ns, h)
  testthat::expect_identical(dr$get_hash(k, ns), h)

  ## Check that *updating* a hash works.
  h2 <- hash_object(h)
  dr$set_hash(k, ns, h2)
  testthat::expect_identical(dr$get_hash(k, ns), h2)

  testthat::expect_true(dr$exists_hash(h))
  testthat::expect_true(dr$exists_key(k, ns))

  ## Then delete the key:
  testthat::expect_true(dr$del_key(k, ns))
  testthat::expect_false(dr$del_key(k, ns))
  testthat::expect_false(dr$exists_key(k, ns))

  ## And delete the hash:
  testthat::expect_true(dr$del_hash(h))
  testthat::expect_false(dr$del_hash(h))
  testthat::expect_false(dr$exists_hash(h))
})

testthat::test_that("namespace", {
  dr <- .driver_create()
  on.exit(dr$destroy())

  ## First, let's set some data to a hash
  d <- runif(100)
  h <- hash_object(d)
  k <- "bbb"
  ns <- "ns"

  dr$set_object(h, d)
  testthat::expect_equal(dr$get_object(h), d, tolerance=1e-15)
  testthat::expect_true(dr$exists_hash(h))

  dr$set_hash(k, ns, h)
  testthat::expect_identical(dr$get_hash(k, ns), h)

  testthat::expect_identical(dr$list_keys(ns), k)
  testthat::expect_true(dr$exists_key(k, ns))

  testthat::expect_true(dr$del_key(k, ns))
  testthat::expect_false(dr$exists_key(k, ns))
  testthat::expect_true(dr$exists_hash(h))

  ## Save into a different namespace:
  ns2 <- "another"
  k2 <- "ccc"

  dr$set_hash(k2, ns2, h)
  testthat::expect_true(dr$exists_key(k2, ns2))
  testthat::expect_identical(dr$get_hash(k2, ns2), h)

  testthat::expect_identical(dr$list_keys(ns), character(0))
  testthat::expect_identical(dr$list_keys(ns2), "ccc")
  testthat::expect_identical(dr$list_hashes(), h)

  testthat::expect_true(dr$del_key(k2, ns2))
  testthat::expect_false(dr$exists_key(k2, ns2))
})
