library(testthat)
library(queuer)

test_check("queuer")
