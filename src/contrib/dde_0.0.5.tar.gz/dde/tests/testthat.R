library(testthat)
library(dde)

test_check("dde")
