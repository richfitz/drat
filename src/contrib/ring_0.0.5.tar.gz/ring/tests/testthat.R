library(testthat)
library(ring)

test_check("ring")
