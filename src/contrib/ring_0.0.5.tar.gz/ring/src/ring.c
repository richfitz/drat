#include <ring/ring.h>
#include <ring/ring.c>
