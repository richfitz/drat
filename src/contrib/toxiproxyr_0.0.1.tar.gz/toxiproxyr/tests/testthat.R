library(testthat)
library(toxiproxyr)

test_check("toxiproxyr")
