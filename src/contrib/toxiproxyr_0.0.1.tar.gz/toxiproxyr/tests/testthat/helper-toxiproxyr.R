takes_more_than <- function(expr) {
  not(takes_less_than(expr))
}
