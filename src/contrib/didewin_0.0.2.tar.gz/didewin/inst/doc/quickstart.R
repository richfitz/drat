## ----eval=FALSE----------------------------------------------------------
#  install.packages("devtools")
#  devtools::install_github(c(
#    "richfitz/ids",
#    "dide-tools/context",
#    "richfitz/queuer",
#    "dide-tools/didewin"))

## ----eval=FALSE----------------------------------------------------------
#  drat:::add("richfitz")
#  install.packages("didewin")

## ----eval=FALSE----------------------------------------------------------
#  install.packages("didewin", repos=c(CRAN="https://cran.rstudio.com",
#                                      drat="https://richfitz.github.io/drat"))

## ----eval=FALSE----------------------------------------------------------
#  didewin::didewin_config_global(cluster="fi--didemrchnb")

## ----eval=FALSE----------------------------------------------------------
#  didewin::didewin_config_global(credentials="rfitzjoh",
#                                 cluster="fi--didemrchnb")

## ----eval=FALSE----------------------------------------------------------
#  didewin::web_login()

## ------------------------------------------------------------------------
packages <- c("ape", "MASS")

## ------------------------------------------------------------------------
sources <- c("mysources.R", "utils.R")

## ----eval=FALSE----------------------------------------------------------
#  ctx <- context::context_save("contexts", packages=packages, sources=sources)

## ----eval=FALSE----------------------------------------------------------
#  obj <- didewin::queue_didewin(ctx)

## ----eval=FALSE----------------------------------------------------------
#  t <- obj$enqueue(sessionInfo())

## ----eval=FALSE----------------------------------------------------------
#  t$wait(120)

