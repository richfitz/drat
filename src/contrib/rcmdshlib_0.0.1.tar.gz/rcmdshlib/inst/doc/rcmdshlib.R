## ----echo = FALSE, results = "hide"--------------------------------------
prepare <- function(code) {
  file <- tempfile(fileext = ".c")
  writeLines(code, file)
  writeLines(c("```c", code, "```"))
  file
}

## ------------------------------------------------------------------------
rcmdshlib::can_compile()

## ----echo = FALSE, results = "asis"--------------------------------------
file <- prepare(c("#include <R.h>",
                  "#include <Rinternals.h>",
                  "SEXP add2(SEXP a, SEXP b) {",
                  "  return ScalarReal(REAL(a)[0] + REAL(b)[0]);",
                  "}"))

## ------------------------------------------------------------------------
file

## ------------------------------------------------------------------------
res <- rcmdshlib::shlib(file)

## ------------------------------------------------------------------------
res$dll

## ------------------------------------------------------------------------
res$output

## ----echo = FALSE, results = "asis"--------------------------------------
file_error <- prepare(c("#include <R.h>",
                        "SEXP add2(SEXP a, SEXP b) {",
                        "  return ScalarReal(REAL(a)[0] + REAL(b)[0]);",
                        "}"))

## ----echo = TRUE, error = TRUE-------------------------------------------
res2 <- rcmdshlib::shlib(file_error, verbose = TRUE)

